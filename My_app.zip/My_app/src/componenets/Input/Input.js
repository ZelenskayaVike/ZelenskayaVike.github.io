import './Input.css'
function Input(){
    return(
        <input type="text" placeholder="Username" id="user" />
    )
    
}
export default Input; 