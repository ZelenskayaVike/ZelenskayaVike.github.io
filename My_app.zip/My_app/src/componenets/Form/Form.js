import Button from '../Buttton/Button';
import InPass from '../InPass/InPass';
import Input from '../Input/Input';
import Logo from '../Logo/Logo';
import './Form.css';

function Form(){
    return(
        <form className="login-form ">
            <Logo></Logo>
            <Input></Input>
            <InPass></InPass>
            <Button></Button>
        </form>       
    )
    
}
export default Form; 