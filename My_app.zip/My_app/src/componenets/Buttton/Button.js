import './Button.css';

function Button(){
    return(
        <button className="myBtn">SIGN IN</button>
    )
    
}
export default Button; 