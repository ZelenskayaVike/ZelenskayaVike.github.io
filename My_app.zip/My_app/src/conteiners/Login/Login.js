import Form from '../../componenets/Form/Form';
import './Login.css'
function Login(){
    return(
        <div className='flexBody'>

        <Form></Form>
        
        </div>

    )
    
}
export default Login; 